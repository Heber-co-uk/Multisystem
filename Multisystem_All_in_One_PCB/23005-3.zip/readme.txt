Company	: HEBER LTD
Board	: 56-23005-3

Information Priority:
This information supercedes any contradictory text in the DRILL DRAWING

2 UP paneliation along the Y-Axis of the board - Panelisation to be approved by Heber before manufacture 

Board Construction:

Material to be 1.6mm FR4 4-layer PCB lead-free (RoHS compliant) with an Electroless Nickel Immersion (ENIG) finish. 
Green solder resist on both sides including vias.

Silkscreen:
White on component face.

BOARD TO BE BARE-BOARD TESTED

Waste Strips:
10mm on top and bottom edges of panel. 
4 off 3.5 mm tooling holes, one in each corner of panel (in waste strip), 5 x 5 mm from edges.
Add fiducials to waste strip corners

Additional Requirements:
Please proved the step-and-repeat data for the paste mask layer.